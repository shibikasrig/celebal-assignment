import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder

# Load dataset
df = pd.read_csv("Housing.csv")

# Encode categorical variables
df['mainroad'] = df['mainroad'].map({'yes': 1, 'no': 0})
df['guestroom'] = df['guestroom'].map({'yes': 1, 'no': 0})
df['basement'] = df['basement'].map({'yes': 1, 'no': 0})
df['hotwaterheating'] = df['hotwaterheating'].map({'yes': 1, 'no': 0})
df['airconditioning'] = df['airconditioning'].map({'yes': 1, 'no': 0})
df['prefarea'] = df['prefarea'].map({'yes': 1, 'no': 0})

# Furnishing status encoding
furnishing_encoder = LabelEncoder()
df['furnishingstatus'] = furnishing_encoder.fit_transform(df['furnishingstatus'])

# Train/test split
X = df.drop('price', axis=1)
y = df['price']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Streamlit UI
st.set_page_config(page_title="Housing Price Predictor")
st.title("🏠 Housing Price Prediction App")

st.write("Fill out the form to predict house price:")

# User input
area = st.number_input("Area (sq ft)", min_value=500, max_value=10000, value=3000)
bedrooms = st.slider("Bedrooms", 1, 10, 3)
bathrooms = st.slider("Bathrooms", 1, 10, 2)
stories = st.slider("Stories", 1, 4, 2)
mainroad = st.selectbox("Main Road", ["Yes", "No"])
guestroom = st.selectbox("Guest Room", ["Yes", "No"])
basement = st.selectbox("Basement", ["Yes", "No"])
hotwaterheating = st.selectbox("Hot Water Heating", ["Yes", "No"])
airconditioning = st.selectbox("Air Conditioning", ["Yes", "No"])
parking = st.slider("Parking", 0, 3, 1)
prefarea = st.selectbox("Preferred Area", ["Yes", "No"])
furnishingstatus = st.selectbox("Furnishing Status", furnishing_encoder.classes_)

# Prediction
if st.button("Predict Price"):
    encoded_furnishing = furnishing_encoder.transform([furnishingstatus])[0]
    input_data = pd.DataFrame({
        'area': [area],
        'bedrooms': [bedrooms],
        'bathrooms': [bathrooms],
        'stories': [stories],
        'mainroad': [1 if mainroad == "Yes" else 0],
        'guestroom': [1 if guestroom == "Yes" else 0],
        'basement': [1 if basement == "Yes" else 0],
        'hotwaterheating': [1 if hotwaterheating == "Yes" else 0],
        'airconditioning': [1 if airconditioning == "Yes" else 0],
        'parking': [parking],
        'prefarea': [1 if prefarea == "Yes" else 0],
        'furnishingstatus': [encoded_furnishing]
    })

    prediction = model.predict(input_data)[0]
    st.success(f"🏡 Predicted House Price: ₹ {round(prediction, 2)}")

# Feature importance
st.subheader("📊 Feature Importance")
importances = model.feature_importances_
feat_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': importances
}).sort_values(by="Importance", ascending=False)

fig, ax = plt.subplots()
sns.barplot(data=feat_df, x='Importance', y='Feature', ax=ax)
st.pyplot(fig)
